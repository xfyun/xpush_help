package com.iflytek.pushclient.test;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.iflytek.autoupdate.UpdateConfig;
import com.iflytek.autoupdate.iFlyUpdate;
import com.iflytek.pushclient.InternalConstant;
import com.iflytek.pushclient.PushManager;
import com.iflytek.pushclient.notification.CustomPushNotificationBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final String TAG = "PushClient_MainActivity";

    private Button btnStartPush;
    private Button btnStopPush;

    private Button btnSetNotificationBuilder;
    private Button btnIsPushEnable;
    private Button btnClearDid;
    private Button btnShowDid;
    private Button btnSendmsg;
    private Button btnBreak;
    private int heartbeat = 0;

    private TextView tvText;
    public static EditText logView;
    private Button btnClearLog;
    private SharedPreferences mSharedPref;
    
    private BindBroadcastReceiver bindReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initUI();
        addListener();
        showInfo();
        initUpdate();
        setBrightnessMode(this);
        PushManager.cleanCaches(this);
        PushManager.setDebugEnable(true);
        //PushManager.setDeviceId("8970623xdc");


    }

    private void initUI() {
        btnStartPush = (Button) findViewById(R.id.btn_startpush);
        btnStopPush = (Button) findViewById(R.id.btn_stoppush);

        btnSetNotificationBuilder = (Button) findViewById(R.id.btn_set_notification_builder);

        btnIsPushEnable = (Button) findViewById(R.id.btn_is_push_enable);

        btnClearDid = (Button) findViewById(R.id.btn_clead_did);
        btnClearDid.setVisibility(View.VISIBLE);

        btnShowDid = (Button) findViewById(R.id.btn_set_heart);

        btnBreak = (Button) findViewById(R.id.btn_break);

        tvText = (TextView) findViewById(R.id.tv_text);

        logView = (EditText) findViewById(R.id.tv_logview);
        logView.setInputType(InputType.TYPE_NULL);
        logView.setSingleLine(false);
        logView.setHorizontallyScrolling(false);

        btnClearLog = (Button) findViewById(R.id.btn_clear_log);
        btnSendmsg = (Button) findViewById(R.id.btn_sendmsg);

    }

    private void addListener() {
        btnStartPush.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                PushManager.startWork(MainActivity.this);
        if(bindReceiver == null){
            bindReceiver = new BindBroadcastReceiver();
            IntentFilter filter = new IntentFilter(BindBroadcastReceiver.ACTION);
            registerReceiver(bindReceiver , filter);
        }

            }
        });

        btnStopPush.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                PushManager.stopWork(MainActivity.this);
            }
        });

        btnSetNotificationBuilder.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                setNotificationBuilder();
            }
        });


        btnIsPushEnable.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                boolean pushEnable = PushManager.isPushEnabled(getApplicationContext());
                if (pushEnable) {
                    Toast.makeText(MainActivity.this, "推送服务正在运行", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, "推送服务未启动", Toast.LENGTH_LONG).show();
                }
            }
        });

        btnClearDid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PushManager.cleanCaches(MainActivity.this.getApplicationContext());
                showInfo();

            }
        });

        btnShowDid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.w("PushSDK++","startsetHeartBeatRate"+ heartbeat);
                if(heartbeat == 0){
                    PushManager.setHeartRate(40*1000,5,MainActivity.this);
                    ++heartbeat;
                }else if(heartbeat < 5){
                    PushManager.setHeartRate((heartbeat+1)*30*1000,5,MainActivity.this);
                    ++heartbeat;
                }else {
                    heartbeat = 0;
                    PushManager.setHeartRate(60*1000,5,MainActivity.this);
                }

            }
        });

        btnClearLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logView.setText("");
            }
        });

        btnSendmsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                onSendMessage();
            }
        });

        btnBreak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PushManager.breakDown(MainActivity.this);
            }
        });
    }

    private void setNotificationBuilder() {
        Resources resource = this.getResources();
        String pkgName = this.getPackageName();
        CustomPushNotificationBuilder cBuilder = new CustomPushNotificationBuilder(
                resource.getIdentifier(
                        "notification_custom_builder", "layout", pkgName),
                resource.getIdentifier("notification_icon", "id", pkgName),
                resource.getIdentifier("notification_title", "id", pkgName),
                resource.getIdentifier("notification_text", "id", pkgName));
        cBuilder.setNotificationFlags(Notification.FLAG_AUTO_CANCEL);
        cBuilder.setNotificationDefaults(Notification.DEFAULT_SOUND
                | Notification.DEFAULT_VIBRATE);
        cBuilder.setStatusbarIcon(this.getApplicationInfo().icon);
        cBuilder.setLayoutDrawable(resource.getIdentifier(
                "simple_notification_icon", "drawable", pkgName));
        PushManager.setNotificationBuilder(this, 2, cBuilder);
        //PushManager.setDefaultNotificationBuilder(this, cBuilder);
    }

    private void clearDid() {
        try {
            android.provider.Settings.System.putString(getContentResolver(), InternalConstant.SETTING_DID, "");
            android.provider.Settings.System.putString(getContentResolver(), InternalConstant.SETTING_SID, "");
            android.provider.Settings.System.putString(getContentResolver(), InternalConstant.SETTING_CLIENTS, "");
        } catch (Exception e) {
            Log.d(TAG, "", e);
            mSharedPref = this.getSharedPreferences("ifly_push_sdk_client", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor =mSharedPref.edit();
            editor.putString(InternalConstant.SETTING_DID,"");
            editor.putString(InternalConstant.SETTING_SID,"");
            editor.putString(InternalConstant.SETTING_CLIENTS,"");
        }
    }

    public static String getAppid(Context context) {
        String result = "";

        try {
            PackageManager pm = context.getPackageManager();
            ApplicationInfo info = pm.getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
            if (info != null) {
                if (info.metaData != null) {
                    Object obj = info.metaData.get("IFLYTEK_APPKEY");
                    String str = obj.toString();
                    if (!TextUtils.isEmpty(str)) {
                        result = str.trim();
                        //外部传入appid 加"'"以避免中间包含e或者纯数字等浮点数的问题。
                        if (result.contains("'")) {
                            result = result.replace("'", "");
                        }
                    }
                }
            }
            if (TextUtils.isEmpty(result)) {
                Log.e(TAG, "Can not find IFLYTEK_APPKEY meta-data from AndroidManifest.xml.");
            }
        } catch (Exception e) {
            Log.e(TAG, "Can not find IFLYTEK_APPKEY meta-data from AndroidManifest.xml.", e);
        }
        return result;
    }

    private void showInfo() {
        String did = "";
        String clients = "";
        try {
            did = android.provider.Settings.System.getString(getContentResolver(), InternalConstant.SETTING_DID);
            clients = android.provider.Settings.System.getString(getContentResolver(), InternalConstant.SETTING_CLIENTS);
        } catch (Exception e) {
            Log.d(TAG, "", e);
            mSharedPref = this.getSharedPreferences("ifly_push_sdk_client", Context.MODE_PRIVATE);
            did = mSharedPref.getString(InternalConstant.SETTING_DID, "");
        }

        StringBuffer buffer = new StringBuffer();
        buffer.append("appId:\t").append(getAppid(this)).append("\n");
        /*buffer.append("did:\t").append(did).append("\n");
        buffer.append("已绑定APP:");*/
        if (!TextUtils.isEmpty(clients)) {
            try {
                JSONArray jsonArray = new JSONArray(clients);
                if (jsonArray != null && jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); ++i) {
                        JSONObject json = jsonArray.optJSONObject(i);
                        String pkgName = json.optString("pkgName");
                        buffer.append("\t").append(pkgName).append("\n");
                    }
                }
            } catch (JSONException e) {
                Log.d(TAG, "", e);
            }
        }

        tvText.setText(buffer.toString());
    }

    private void sendHeartbeat() {

    }

    private void initUpdate() {
        //设置更新提醒样式，DIAGSTYLE：对话框方式，NOTISTYLE：通知栏方式
        iFlyUpdate.setUpdateStlye(UpdateConfig.UpdateStyle.DIAGSTYLE);

        //传入当前Activity的Context
        iFlyUpdate.update(MainActivity.this);

        //开启调试模式，默认不开启
        iFlyUpdate.setDebugMode(true);
    }

    private void onSendMessage() {
        SendDialog dialog = new SendDialog(this, R.style.SendDialog);
        dialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        PushManager.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();

    }
    
    @Override
    protected void onDestroy() {
    	super.onDestroy();
    	
    	if (null != bindReceiver) {
			unregisterReceiver(bindReceiver);
		}
    }
    
    public class BindBroadcastReceiver extends BroadcastReceiver {
    	public static final String ACTION = "com.iflytek.xpush.Action.bind";
    	
    	@Override
    	public void onReceive(Context context, Intent intent) {
    		showInfo();
    	}
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        switch (requestCode) {
            case 1122: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.e(TAG,"permission request successed");
                } else {
                    Log.e(TAG,"permission request failed");
                }
                return;
            }
        }
    }

    private void setBrightnessMode(Context context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                int permission = ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE);
                if(permission!= PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this,new String[] {
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.LOCATION_HARDWARE,
                            Manifest.permission.READ_PHONE_STATE,
                            Manifest.permission.WRITE_SETTINGS},1122);
                }
                if (!Settings.System.canWrite(context)) {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                            Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, 112233);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 112233) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // 判断是否有WRITE_SETTINGS权限
                if (Settings.System.canWrite(this)) {
                    PushManager.startWork(this);
                    bindReceiver = new BindBroadcastReceiver();
                    IntentFilter filter = new IntentFilter(BindBroadcastReceiver.ACTION);
                    registerReceiver(bindReceiver , filter);
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
