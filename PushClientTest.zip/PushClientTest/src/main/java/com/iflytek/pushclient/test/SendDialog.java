package com.iflytek.pushclient.test;

import android.app.Dialog;
import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by wzc on 2015/2/11.
 */
public class SendDialog extends Dialog {
    private static final String TAG = "SendDialog";
    private Context context;

    private EditText etContent;
    private Button btnSend;
    private RadioGroup rgMsgType;

    public SendDialog(Context context) {
        super(context);
        this.context = context;
        initUI();
        addListener();
    }

    public SendDialog(Context context, int theme) {
        super(context, theme);
        this.context = context;
        initUI();
        addListener();
    }

    protected SendDialog(Context context, boolean cancelable, OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
        this.context = context;
        initUI();
        addListener();
    }

    private void initUI() {
        setContentView(R.layout.activity_send);

        etContent = (EditText) findViewById(R.id.edittext_content);

        btnSend = (Button) findViewById(R.id.btn_send);
        rgMsgType = (RadioGroup) findViewById(R.id.rg_msg_type);
    }

    private void addListener() {
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onSend();
            }
        });
    }

    private int getMsgType() {
        int msgType = 0;
        if (rgMsgType.getCheckedRadioButtonId() == R.id.rd_type_message) {
            msgType = 1;
        }
        return msgType;
    }

    private void onSend() {
        String text = etContent.getText().toString();
        if (TextUtils.isEmpty(text)) {
            Toast.makeText(context, "文本为空", Toast.LENGTH_LONG).show();
            return;
        }

        String msg = "";
        try {
            JSONObject json = new JSONObject();
            json.putOpt("content", text);
            json.putOpt("msg_type", getMsgType());
            json.putOpt("title", "");
            //json.putOpt("appid", Constants.APP_ID);
            msg = json.toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestParams params = new RequestParams();

        //msg = "{\"title\":\"xpush2.0-test-title\",\"content\":\"hello world\",\"msg_type\":\"0\"}";
        Log.d(TAG, "onSend | msg = " + msg);
        params.addBodyParameter("message", msg);
        params.addBodyParameter("push_type", "1");
        params.addBodyParameter("expires", "36000");
        params.addBodyParameter("did", "d776345090");
        params.addBodyParameter("appid", Constants.APP_ID);

        HttpUtils httpUtils = new HttpUtils();
       /* httpUtils.send(HttpRequest.HttpMethod.POST, Constants.URL, params, new RequestCallBack<String>() {

            @Override
            public void onSuccess(ResponseInfo<String> stringResponseInfo) {
                String result = stringResponseInfo.result;

                Log.d(TAG, "" + result);
                onResult(result);
            }

            @Override
            public void onFailure(HttpException e, String s) {
                Log.d(TAG, "onFailure |  " + s, e);
                Toast.makeText(context, "网络异常", Toast.LENGTH_LONG).show();
            }
        });*/
    }

    private void onResult(String result) {
        if (TextUtils.isEmpty(result)) {
            Toast.makeText(context, "网络异常", Toast.LENGTH_LONG).show();
            return;
        }

        int ret = -1;
        try {
            JSONObject json = new JSONObject(result);
            ret = json.optInt("ret");
        } catch (Exception e) {
            Log.d(TAG, "", e);
        }

        if (ret == 0) {
            Toast.makeText(context, "发送成功", Toast.LENGTH_LONG).show();
            dismiss();
        } else {
            Toast.makeText(context, "发送失败", Toast.LENGTH_LONG).show();
        }
    }
}
