package com.iflytek.pushclient.test;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.iflytek.pushclient.PushReceiver;
import com.iflytek.pushclient.test.MainActivity.BindBroadcastReceiver;

/**
 * Created by wzc on 2015/1/19.
 */
public class MyPushReceiver extends PushReceiver {
    private static final String TAG = "MyPushReceiver";

    /**
     * 调用PushManager.startWork后，sdk将对 push server发起绑定请求，这个过程是异步
     * 的。绑定请求的结果通过onBind返回。
     */
    @Override
    protected void onBind(Context context, String did, String appId, int errorCode) {
        Log.d(TAG, "onBind | did = " + did + ",appId = " + appId + ", errorCode = " + errorCode);
        
        Intent intent = new Intent(BindBroadcastReceiver.ACTION);
        context.sendBroadcast(intent);
    }

    /**
     * 调用PushManager.stopWork后，sdk将对该应用进行解绑，该应用的消息不不再被通知
     *
     * @param context
     * @param did
     * @param appId
     * @param errorCode
     */
    @Override
    protected void onUnBind(Context context, String did, String appId, int errorCode) {
        Log.d(TAG,  "onUnBind | did = " + did + ",appId = " + appId + ", errorCode = " + errorCode);
    
        Intent intent = new Intent(BindBroadcastReceiver.ACTION);
        context.sendBroadcast(intent);
    }

    /**
     * 接收透传消息的函数。
     *
     * @param context
     * @param msgId   消息的id
     * @param content 透传消息的内容，由各应用自己解析
     */
    @Override
    protected void onMessage(Context context, String msgId, byte[] content) {
        String body = new String(content);
        Log.d(TAG, "onMessage | msgId = " + msgId + ", content = " + body);

        String msg = "收到透传消息 msgId = " + msgId + ", content = " +  body;
        Toast.makeText(context, msg, Toast.LENGTH_LONG).show();
        if (MainActivity.logView != null){
            MainActivity.logView.append(msg + "\n");
        }
    }

    /**
     * 接收通知点击的函数。注：推送通知被用户点击前，应用无法通过接口获取通知的内容。
     *
     * @param context
     * @param messageId
     * @param title
     * @param content
     */
    @Override
    protected void onClickNotification(Context context, String messageId, String title, String content, String extraContent) {
        Log.d(TAG, "onClickNotification | msgId = " + messageId + ", title = " + title
        + ", content" + content + ", extraContent = " + extraContent);

    }
    @Override
    protected void onTags(Context var1, String var2, String var3, int var4) {

    }

    @Override
    protected void onStateChanged(Context context, int state) {
        Log.d(TAG,"onStateChanged | state is: "+state);
    }
}
