package com.iflytek.pushclient.test;

/**
 * Created by wzc on 2015/2/10.
 */
public class Constants {
    public static final String APP_ID = "581edac5";
}
