package com.iflytek.pushclient.test;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by wzc on 2015/2/10.
 */
public class SendActivity extends Activity {

    private static final String TAG = "SendActivity";

    private EditText etContent;
    private Button btnSend;
    private HttpUtils httpUtils;
    private RadioGroup rgMsgType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_send);


        initUI();
        addListener();

        httpUtils = new HttpUtils();
    }

    private void initUI() {

        etContent = (EditText) findViewById(R.id.edittext_content);

        btnSend = (Button) findViewById(R.id.btn_send);
        rgMsgType = (RadioGroup) findViewById(R.id.rg_msg_type);
    }

    private void addListener() {
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onSend();
            }
        });
    }

    private int getMsgType() {
        int msgType = 0;
        if (rgMsgType.getCheckedRadioButtonId() == R.id.rd_type_message) {
            msgType = 1;
        }
        return msgType;
    }

    private void onSend() {
        String text = etContent.getText().toString();
        if (TextUtils.isEmpty(text)) {
            Toast.makeText(this, "文本为空", Toast.LENGTH_LONG).show();
            return;
        }

        String msg = "";
        try {
            JSONObject json = new JSONObject();
            json.putOpt("content", text);
            json.putOpt("msg_type", getMsgType());
            json.putOpt("title", "");
            //json.putOpt("appid", Constants.APP_ID);
            msg = json.toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestParams params = new RequestParams();

        //msg = "{\"title\":\"xpush2.0-test-title\",\"content\":\"hello world\",\"msg_type\":\"0\"}";
        Log.d(TAG, "onSend | msg = " + msg);
        params.addBodyParameter("message", msg);
        params.addBodyParameter("push_type", "1");
        params.addBodyParameter("expires", "36000");
        params.addBodyParameter("did", "d776345090");
        params.addBodyParameter("appid", Constants.APP_ID);

       /* httpUtils.send(HttpRequest.HttpMethod.POST, Constants.URL, params, new RequestCallBack<String>() {

            @Override
            public void onSuccess(ResponseInfo<String> stringResponseInfo) {
                String result = stringResponseInfo.result;
                Toast.makeText(SendActivity.this, "" + result, Toast.LENGTH_LONG).show();
                Log.d(TAG, "" + result);
            }

            @Override
            public void onFailure(HttpException e, String s) {
                Log.d(TAG, "onFailure |  " + s, e);
                Toast.makeText(SendActivity.this, "网络异常", Toast.LENGTH_LONG).show();
            }
        });*/
    }
}
